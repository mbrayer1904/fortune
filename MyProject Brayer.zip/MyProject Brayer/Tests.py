def color_len_test():
    assert player_choice('Color', 'RED') == 3
    assert player_choice('Color', 'GREEN') == 5
    assert player_choice('Color', 'YELLOW') == 6
    assert player_choice('Color', 'BLUE') == 4
    
def first_choice_test():
    assert first_choices('RED') == ['1', '2', '5', '6']
    assert first_choices('GREEN') == ['1', '2', '5', '6']
    assert first_choices('YELLOW') == ['3', '4', '7', '8']
    assert first_choices('BLUE') == ['3', '4', '7', '8']
    
def second_choice_test():
    assert second_choices(3, 5) == ['3', '4', '7', '8']
    assert second_choices(4, 3) == ['1', '2', '5', '6']
    assert second_choices(6, 7) == ['1', '2', '5', '6']
    assert second_choices(4, 4) == ['3', '4', '7', '8']
    assert second_choices(5, 2) == ['1', '2', '5', '6']
    
    